#' hal9001
#'
#' Package for fitting the Highly Adaptive LASSO (HAL) estimator
#'
#' @name hal9001
#'
#' @importFrom Rcpp sourceCpp
#' @useDynLib hal9001
#
NULL
