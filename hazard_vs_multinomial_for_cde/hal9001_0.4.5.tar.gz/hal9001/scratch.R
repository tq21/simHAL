library(glmnet)
load_all()

set.seed(123)
n <- 100
X <- cbind(rnorm(n), rnorm(n))
Y <- rbinom(n, 2, plogis(0.5*X))


hal_fit <- fit_hal(X = X,
                   Y = Y,
                   family = "multinomial")
pred <- predict(hal_fit, new_data = X, type = "response")
rowSums(pred)

fit <- cv.glmnet(x = X, y = Y, family = "multinomial", alpha = 1)
coef(fit, s = "lambda.min")

coefs_0 <- as.numeric(coef(fit, s = "lambda.min")$`0`)
coefs_1 <- as.numeric(coef(fit, s = "lambda.min")$`1`)
coefs_2 <- as.numeric(coef(fit, s = "lambda.min")$`2`)

pred_0 <- as.numeric(cbind(1, X) %*% coefs_0)
pred_1 <- as.numeric(cbind(1, X) %*% coefs_1)
pred_2 <- as.numeric(cbind(1, X) %*% coefs_2)

prob_0 <- exp(pred_0) / (exp(pred_0) + exp(pred_1) + exp(pred_2))
prob_1 <- exp(pred_1) / (exp(pred_0) + exp(pred_1) + exp(pred_2))
prob_2 <- exp(pred_2) / (exp(pred_0) + exp(pred_1) + exp(pred_2))

prob_0[1] + prob_1[1] + prob_2[1]
prob_0[2] + prob_1[2] + prob_2[2]


lapply(coef(fit, s = "lambda.min"), function(.coef) {
  Matrix::tcrossprod(x = as.matrix(cbind(1, X)), y = t(matrix(.coef)))
})




